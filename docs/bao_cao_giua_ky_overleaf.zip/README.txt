BÁO CÁO GIỮA KỲ — 3.000 MẪU / LƯỢT

Upload toàn bộ ZIP này bằng New Project > Upload Project trên Overleaf.
Main document: bao_cao_giua_ky.tex. Compiler: pdfLaTeX.
Giữ nguyên thư mục images/; chỉ tải tệp .tex sẽ thiếu ảnh.
Sơ đồ hệ thống và biểu đồ được vẽ trực tiếp bằng TikZ/PGFPlots.
Nguồn và checksum ảnh: images/theory/sources.json.

Số liệu: 28 lượt của cohort chính, 3.000 mẫu/lượt; đã đối chiếu
84.000 dự đoán với nhãn thật và summary. File experiments/ chứa
bảng kết quả và biên bản kiểm tra tổng hợp, không chứa dữ liệu gốc.
Nguồn split: validation Fakeddit, train chung CrisisMMD, test MM-IMDb.
Không có PDF trong gói này.
